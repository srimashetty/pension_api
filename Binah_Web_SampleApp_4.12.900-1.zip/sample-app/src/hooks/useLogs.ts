import { useCallback, useEffect } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

export interface LogFile {
  fileName: string;
  data: string;
}

const useLogs = (logsTitle: string): void => {
  const handleLogs = useCallback(
    async (logs: LogFile[], formattedDate: string) => {
      const zip = new JSZip();

      for (const { fileName, data } of logs) {
        let dataToWrite: string | Blob = data;
        zip.file(fileName, dataToWrite);
      }

      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, `${logsTitle}_${formattedDate}.zip`);
    },
    [logsTitle],
  );

  useEffect(() => {
    window['handleLogs'] = handleLogs;
  }, [logsTitle]);
};

export default useLogs;
